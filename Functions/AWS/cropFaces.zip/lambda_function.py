import json
import logging
import os
import uuid
from typing import Dict, Tuple

from PIL import Image
from storage.pyStorage import pyStorage

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    dst_bucket = event["destinationPath"]   # e.g. s3://daecc-bucket-nv/celebrities/
    remote_image = event["image"]           # e.g., s3://daecc-bucket-nv/images/LotR.png
    celebrities = event["celebrities"]

    filename, extension = os.path.splitext(remote_image)
    local_image = "/tmp/image" + extension

    pyStorage.create_cred_file(
        aws_access_key_id=event['aws_access_key_id'], 
        aws_secret_key=event['aws_secret_key'], 
        aws_session_token=event['aws_session_token'],                       
        gcp_client_email=event['gcp_client_email'], 
        gcp_private_key=event['gcp_private_key'], 
        gcp_project_id=event['gcp_project_id']
    )

    pyStorage.copy(remote_image, local_image)  
    
    with Image.open(local_image) as img:
        for celebrity in celebrities: 
            bounding_box = celebrity["BoundingBox"]
            name = celebrity["Name"]

            logger.info(f"Extracting celebrity: {name}")
            
            img_name = generate_filename(extension)
            local_img_path = os.path.join("/tmp", img_name)

            img_dir = build_dirname(name)
            remote_img_path = os.path.join(dst_bucket, img_dir, img_name)
            
            celebrity_img = crop_face(img, bounding_box)
            
            # Temporarily save the image as file to upload it
            celebrity_img.save(local_img_path)
            
            upload_img(local_img_path, remote_img_path)

    return {
        "destinationPath": event["destinationPath"],
        "aws_access_key_id": event["aws_access_key_id"],
        "aws_secret_key": event["aws_secret_key"],
        "aws_session_token": event["aws_session_token"],
        "gcp_project_id": event["gcp_project_id"],
        "gcp_private_key": event["gcp_private_key"],
        "gcp_client_email": event["gcp_client_email"]
    }


def build_dirname(celebrity_name: str) -> str:
    """Build the name of the image directory using the name of the Celebrity."""
    dirname = celebrity_name.replace(" ", "_")
    dirname = dirname.lower()
    dirname = os.path.join(dirname, "crops")
    
    return dirname
    

def generate_filename(extension: str) -> str:
    """Generate random file name for the image."""
    f = str(uuid.uuid4().hex) + extension
    return f


def crop_face(img: Image, bounding_box: Dict) -> Image:
    """Extract the face from the full image.
    
    AWS provides the bounding box values as ratio of the overall image size. 
    Thus the values (left, top, ...) are between [0, 1]. 
    To get the true image coordinates the values have to be multiplied with the image width and height.

    """
    
    img_width, img_height = img.size
    
    left: int = int(bounding_box["Left"] * img_width)
    right: int = int(left + (bounding_box["Width"] * img_width))
    
    top: int = int(bounding_box["Top"] * img_height)
    bottom: int = int(top + (bounding_box["Height"] * img_height))
    
    cropped_image = img.crop((left, top, right, bottom))
    
    return cropped_image


def upload_img(local_filepath: str, remote_filepath: str) -> None: 
    """Upload the image into S3 bucket."""
    pyStorage.copy(local_filepath, remote_filepath)  
